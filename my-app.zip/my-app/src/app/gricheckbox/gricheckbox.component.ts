import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp} from "ag-grid-angular";

@Component({
  selector: 'app-gricheckbox',
  templateUrl: './gricheckbox.component.html',
  styleUrls: ['./gricheckbox.component.css']
})
export class GricheckboxComponent implements ICellRendererAngularComp {

  constructor() { }

  agInit(params: any): void {
    console.log(params);
  }

  refresh(): boolean {
    return false;
  }

  onGridRowCheck(event):void{

  }

}
