import {Component, OnInit, Input, SimpleChanges, OnChanges, SimpleChange} from '@angular/core';
import {SharedService} from "../services/shared.service";

@Component({
  selector: 'app-app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.css']
})
export class AppHeaderComponent implements OnInit, OnChanges {

  public approveFlag: boolean = false;
  public rejectFlag: boolean = false;

  constructor(private sharedService:SharedService) {

  }

  ngOnInit() {

  }
  changeLog: string[] = [];

  ngOnChanges(changes: {[propKey: string]: SimpleChange}){
    let log: string[] = [];
    for (let propName in changes) {
      let changedProp = changes[propName];
      let to = JSON.stringify(changedProp.currentValue);
        if (changedProp.isFirstChange()) {
          log.push(`Initial value of ${propName} set to ${to}`);
        } else {
          let from = JSON.stringify(changedProp.previousValue);
          log.push(`${propName} changed from ${from} to ${to}`);
        }
    }
     this.changeLog.push(log.join(', '));
  }

  enableButtons(){
      this.approveFlag = true;
      this.rejectFlag = true;
  }

  disableButtons(){
    this.approveFlag = false;
    this.rejectFlag = false;
  }

}
