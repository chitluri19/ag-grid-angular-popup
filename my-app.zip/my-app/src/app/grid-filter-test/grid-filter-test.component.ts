import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-filter-test',
  templateUrl: './grid-filter-test.component.html',
  styleUrls: ['./grid-filter-test.component.css']
})
export class GridFilterTestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
