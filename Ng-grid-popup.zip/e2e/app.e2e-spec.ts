import { NgAgridPage } from './app.po';

describe('ng-agrid App', () => {
  let page: NgAgridPage;

  beforeEach(() => {
    page = new NgAgridPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!');
  });
});
