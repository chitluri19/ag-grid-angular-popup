import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartialMatchFilterComponent } from './partial-match-filter.component';

describe('PartialMatchFilterComponent', () => {
  let component: PartialMatchFilterComponent;
  let fixture: ComponentFixture<PartialMatchFilterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartialMatchFilterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartialMatchFilterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
