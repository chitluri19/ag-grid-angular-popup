import { Component } from '@angular/core';
import { DataListModule } from 'primeng/primeng';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  data:any;
  title = 'app';
  showPopup:boolean;

  constructor(){
    this.data={
      id:'9',
      name:'Venkatesh'
    };
    this.showPopup=false;
  }

  openPopup(){
      this.showPopup= true;
  }
}
