import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailspaneComponent } from './detailspane.component';

describe('DetailspaneComponent', () => {
  let component: DetailspaneComponent;
  let fixture: ComponentFixture<DetailspaneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailspaneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailspaneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
