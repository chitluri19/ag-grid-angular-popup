import { Injectable } from '@angular/core';

@Injectable()
export class GridService {

  constructor() {

  }

  getData(){
    var volumes = [
      { "name":"Abc","age":29,"dob":"11/08/1988","address":"Aspet" },
      { "name":"Xyz","age":55,"dob":"11/08/1950","address":"Kmm"},
      { "name":"Def","age":78,"dob":"11/08/1978","address":"TG" },
      { "name":"Ghm","age":89,"dob":"11/08/1990","address":"IND" },
      { "name":"Kfc","age":21,"dob":"11/08/2000","address":"Asian" }
    ]
    return volumes;
  }

}
