import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {AgGridModule} from 'ag-grid-angular/main';

import { AppComponent } from './app.component';
import { TestNgComponent } from './test-ng/test-ng.component';
import { EditComponent } from './edit/edit.component';
import { DeleteComponent } from './delete/delete.component';
import { EditIconComponent } from './edit-icon/edit-icon.component';
import { DeleteIconComponent } from './delete-icon/delete-icon.component';
import {RouterModule, Routes} from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {CommonModule} from '@angular/common';

export const routes: Routes = [
  { path : 'edit' , component : EditComponent },
  { path : 'delete' , component : DeleteComponent },
]

@NgModule({
  declarations: [
    AppComponent,
    TestNgComponent,
    EditComponent,
    DeleteComponent,
    EditIconComponent,
    DeleteIconComponent,
  ],
  imports: [
    BrowserModule,
    AgGridModule.withComponents(
      [ TestNgComponent, EditIconComponent , DeleteIconComponent,EditComponent ]),
    RouterModule.forRoot(routes),
    NgbModule.forRoot(),
    CommonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
