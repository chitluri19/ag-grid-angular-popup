import { Component, Input, OnInit} from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  @Input()
  showPopUp: boolean;

  private params: any = {};

  constructor(private modalService: NgbModal) {
    console.log(this.showPopUp);
  }

  ngOnInit() {
    console.log(this.showPopUp);
  }

  agInit(params: any ) {

  }

}
