import { Component, OnInit } from '@angular/core';
import {GridService} from "../services/grid.service";

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent implements OnInit {

  public gridDataSource : Array<Object> = [];

  constructor(private gridService:GridService) {
  }

  ngOnInit() {
     this.gridDataSource = this.gridService.getData();
  }

}
