import {Component, ViewChild} from '@angular/core';
import {GridOptions} from "ag-grid";
import {DetailspaneComponent} from "../detailspane/detailspane.component";
import {SharedService} from "../services/shared.service";
import {AppHeaderComponent} from "../app-header/app-header.component";
import {PartialMatchFilterComponent} from "../partial-match-filter/partial-match-filter.component";

@Component({
  selector: 'app-aggridtest',
  templateUrl: './aggridtest.component.html',
  styleUrls: ['./aggridtest.component.css']
})
export class AggridtestComponent {

  private approveFlag:boolean = false;
  private rejectFlag:boolean = false;

  @ViewChild(AppHeaderComponent) private appHeaderComponent: AppHeaderComponent;


  public gridOptions: GridOptions;
  public params: any;
  public rowsArray : Array<Object> = [
  {"rowId": "Row 1", "name": "Michael Phelps"},
  {"rowId": "Row 2", "name": "Natalie Coughlin"},
  {"rowId": "Row 3", "name": "Aleksey Nemov"},
  {"rowId": "Row 4", "name": "Alicia Coutts"},
  {"rowId": "Row 5", "name": "Missy Franklin"},
  {"rowId": "Row 6", "name": "Ryan Lochte"},
  {"rowId": "Row 7", "name": "Allison Schmitt"},
  {"rowId": "Row 8", "name": "Natalie Coughlin"},
  {"rowId": "Row 9", "name": "Ian Thorpe"},
  {"rowId": "Row 10", "name": "Bob Mill"},
  {"rowId": "Row 11", "name": "Willy Walsh"},
  {"rowId": "Row 12", "name": "Sarah McCoy"},
  {"rowId": "Row 13", "name": "Jane Jack"},
  {"rowId": "Row 14", "name": "Tina Wills"}
  ];

  agInit(params: any): void {

    this.params = params;
  }

  constructor(private sharedService:SharedService) {
    this.gridOptions = <GridOptions>{};
    this.gridOptions.rowData = this.createRowData();
    this.gridOptions.columnDefs = this.createColumnDefs();
    this.gridOptions.enableFilter = true;
  }

  private createColumnDefs(){
    return [
      { headerName: 'Name', field: 'rowId',checkboxSelection: true, filterFramework: PartialMatchFilterComponent, suppressSorting: true,cellRenderer: 'group' },
      { headerName: 'Account', field: 'name',fitter:'string', filterFramework: PartialMatchFilterComponent },
    ];
  }

  private createRowData(){
    let rowData: any[] = [];
    for(var k = 0; k < this.rowsArray.length ; k++){

      /*let callRecords = [];

      let callRecord = {
        callId:this.rowsArray[k]['rowId'],
        direction:this.rowsArray[k]['name']
      }

      callRecords.push(callRecord);*/

      let record = {
        rowId : this.rowsArray[k]['rowId'],
        name : this.rowsArray[k]['name'],
        callRecords : [{
          callId : 1,
          direction :'In'
        }]
      }
      rowData.push(record);
    }
    return rowData;
  }

  public isFullWidthCell(rowNode) {
    return rowNode.level === 1;
  }

  public getRowHeight(params) {
    var rowIsDetailRow = params.node.level === 1;
    // return 100 when detail row, otherwise return 25
    return rowIsDetailRow ? 200 : 25;
  }

  public getNodeChildDetails(record) {
    if(record.callRecords){
      if(record.callRecords['IsChild']){
        return null;
      }else{
        record['callRecords']['IsChild'] = true;
        return {
          group: true,
          // the key is used by the default group cellRenderer
          key: record.rowId,
          // provide ag-Grid with the children of this group
          children: [record.callRecords]
        };
      }
    }


    /*if (record.callRecords) {
      record.callRecords['IsChild'] = true;
      return {
        group: true,
        // the key is used by the default group cellRenderer
        key: record.rowId,
        // provide ag-Grid with the children of this group
        children: [record.callRecords]
      };
    } else {
      return null;
    }*/
  }

  public getFullWidthCellRenderer() {
    return DetailspaneComponent;
  }

  public onSelectionChanged($event:any){
    let global = this;
    let count=0;
    var selectedRows = this.gridOptions.api.getSelectedRows();
    var selectedRowsString = '';
    selectedRows.forEach( function(selectedRow, index) {
        count++;
        if(count > 0){
          console.log("selectedRow...:",count);
          global.approveFlag = true;
          global.rejectFlag = true;
          global.appHeaderComponent.enableButtons();
        }else{
          global.approveFlag = false;
          global.rejectFlag = false;
          global.appHeaderComponent.disableButtons();
        }
    });
  }

  private onRowClicked($event) {
    console.log('onRowClicked: ' + $event.node.data.rowId);
  }

  public onCellClicked($event:any){
    console.log($event);
  }

}
