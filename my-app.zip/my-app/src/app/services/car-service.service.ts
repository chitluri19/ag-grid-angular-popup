import { Injectable } from '@angular/core';
import {Http, Response} from '@angular/http';


export interface Car {
  vin;
  year;
  brand;
  color;
}


@Injectable()
export class CarServiceService {

  constructor(private http: Http) { }

  getCarsLarge() {
   /* return this.http.get('')
      .toPromise()
      .then(res => <Car[]> res.json().data)
      .then(data => { return data; });*/

    return this.http.get('')
      .subscribe(res =>{
         var data = res.json();

      })

  }

}
