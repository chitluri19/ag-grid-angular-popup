import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridFilterTestComponent } from './grid-filter-test.component';

describe('GridFilterTestComponent', () => {
  let component: GridFilterTestComponent;
  let fixture: ComponentFixture<GridFilterTestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridFilterTestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridFilterTestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
