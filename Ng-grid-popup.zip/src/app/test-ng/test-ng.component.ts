import { Component, OnInit } from '@angular/core';
import { GridOptions } from 'ag-grid/main';
import { EditIconComponent } from '../edit-icon/edit-icon.component' ;
import { DeleteIconComponent } from '../delete-icon/delete-icon.component';


@Component({
  selector: 'app-test-ng',
  templateUrl: './test-ng.component.html',
  styleUrls: ['./test-ng.component.css']
})
export class TestNgComponent implements OnInit {

   gridOptions: GridOptions;
   columnDefs: any[];
   rowData: any[];

  constructor() {

    this.gridOptions = <GridOptions>{
      enableSorting: true,
      enableFilter: true,
      enableColResize: true,
      getRowHeight: function() {
        return 40;
      }
    };

    this.columnDefs = [
      {headerName: 'Make', field: 'make'},
      {
        headerName: 'Model', field: 'model', cellRendererFramework: EditIconComponent, width : 200 , height : 40
      },
      {headerName: 'Price', field: 'price', cellRendererFramework: DeleteIconComponent , width : 200 , height : 40 }
    ];

    this.rowData = [
      {make: 'Toyota', model: 'Celica', price: 35000},
      {make: 'Ford', model: 'Mondeo', price: 32000},
      {make: 'Porsche', model: 'Boxter', price: 72000}
    ];
  }

  ngOnInit() {
  }

  navigate(event) {
    alert( ' Inside pop up ' );
    console.log('sdfsdfsdfd');
  }

}
