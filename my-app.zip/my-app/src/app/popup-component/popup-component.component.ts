import {Component, OnInit, Input, OnChanges,SimpleChange } from '@angular/core';
import { Observable } from 'rxjs/Observable';


const ObserveInput = (key) => (target, prop) => {
  //register w/ angular
  Input(key)(target,key);

  let onNext;

  target[prop] = new Observable(obs => {
    onNext = (v) => obs.next(v);
    return () => {
      onNext = undefined;
    }
  });

  Object.defineProperty(target, key, {
    set(v){
      if(onNext){
        onNext(v);
      }
    }
  });
}

@Component({
  selector: 'app-popup-component',
  templateUrl: 'popup-component.component.html',
  styleUrls: ['popup-component.component.css']
})
export class PopupComponentComponent implements OnInit, OnChanges {

  @Input() data:any;
  @ObserveInput('popup') showPopup: Observable<boolean>;
  //@Input() showPopup:boolean;
  showPopupFlag:boolean;

  constructor() {
    this.showPopup.subscribe(flag=> {
        console.log("ShowPopUp...:",flag);
        this.showPopupFlag = flag;
    });
  }

  ngOnInit() {
    this.showPopup.subscribe(flag=> {
      console.log("ShowPopUp...:",flag);
      this.showPopupFlag = flag;
    });
  }

  ngOnChanges(changes: {[propKey: string]: SimpleChange}) {
    let log: string[] = [];
    for (let propName in changes) {
      let changedProp = changes[propName];
      let to = JSON.stringify(changedProp.currentValue);
      if (changedProp.isFirstChange()) {
        log.push(`Initial value of ${propName} set to ${to}`);
      } else {
        let from = JSON.stringify(changedProp.previousValue);
        log.push(`${propName} changed from ${from} to ${to}`);
      }
    }
  }

}
