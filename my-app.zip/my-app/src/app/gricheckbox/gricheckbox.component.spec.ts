import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GricheckboxComponent } from './gricheckbox.component';

describe('GricheckboxComponent', () => {
  let component: GricheckboxComponent;
  let fixture: ComponentFixture<GricheckboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GricheckboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GricheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
