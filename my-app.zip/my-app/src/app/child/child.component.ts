import {Component, OnInit, OnChanges, SimpleChanges, Input} from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit,OnChanges {

  @Input()
  data:String = '';

  constructor() { }

  ngOnInit() {
    this.data += this.data + 'Appended to child'
  }

  ngOnChanges(changes:SimpleChanges){
    console.log(changes);
  }

}
