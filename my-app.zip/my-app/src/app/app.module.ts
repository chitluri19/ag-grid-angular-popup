import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PopupComponentComponent } from './popup-component/popup-component.component';
import { DatatableComponent } from './components/datatable/datatable.component';
import { DataTableModule,SharedModule} from 'primeng/primeng';
import { InputTextareaModule } from "primeng/components/inputtextarea/inputtextarea";
import { FormsModule } from "@angular/forms";
import { PanelModule } from "primeng/components/panel/panel";
import { DropdownModule } from "primeng/components/dropdown/dropdown";
import { AggridtestComponent } from './aggridtest/aggridtest.component';
import { AgGridModule } from "ag-grid-angular";
import { DetailspaneComponent } from './detailspane/detailspane.component';
import { AppHeaderComponent } from './app-header/app-header.component';
import { GricheckboxComponent } from './gricheckbox/gricheckbox.component';
import {SharedService} from "./services/shared.service";
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { GridComponent } from './grid/grid.component';
import {GridService} from "./services/grid.service";
import { PartialMatchFilterComponent } from './partial-match-filter/partial-match-filter.component';
import { GridFilterTestComponent } from './grid-filter-test/grid-filter-test.component';


@NgModule({
  declarations: [
    AppComponent,
    PopupComponentComponent,
    DatatableComponent,
    AggridtestComponent,
    DetailspaneComponent,
    AppHeaderComponent,
    GricheckboxComponent,
    ParentComponent,
    ChildComponent,
    GridComponent,
    PartialMatchFilterComponent,
    GridFilterTestComponent,
  ],
  imports: [
    BrowserModule,
    DataTableModule,
    InputTextareaModule,
    FormsModule,
    PanelModule,
    DropdownModule,
    AgGridModule.withComponents(
      [ AggridtestComponent,
        DetailspaneComponent,
        GricheckboxComponent,
        PartialMatchFilterComponent,
        GridFilterTestComponent])
  ],
  providers: [ SharedService,GridService ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
